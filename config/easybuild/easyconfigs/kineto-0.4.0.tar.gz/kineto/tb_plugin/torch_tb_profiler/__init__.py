# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------

# Entry point for Pytorch TensorBoard plugin package.

__version__ = '0.4.0'
