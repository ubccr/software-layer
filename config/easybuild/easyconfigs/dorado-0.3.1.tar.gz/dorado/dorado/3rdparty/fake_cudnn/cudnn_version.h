#define CUDNN_MAJOR 8
