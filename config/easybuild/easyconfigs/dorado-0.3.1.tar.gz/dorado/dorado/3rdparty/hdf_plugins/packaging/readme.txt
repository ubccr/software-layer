Oxford Nanopore VBZ hdf plugin
==============================

This package will install an hdf plugin which can read and write the nanopore vbz data format.

Once installed hdf5 tools will automatically read vbz datasets.