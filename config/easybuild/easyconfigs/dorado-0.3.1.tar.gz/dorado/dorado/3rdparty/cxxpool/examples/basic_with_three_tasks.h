#pragma once
#include <iostream>

namespace examples {

void basic_with_three_tasks(std::ostream& os);

}
